<?php

namespace App\Filament\Resources\BadalResource\Pages;

use App\Filament\Resources\BadalResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBadal extends CreateRecord
{
    protected static string $resource = BadalResource::class;
}
